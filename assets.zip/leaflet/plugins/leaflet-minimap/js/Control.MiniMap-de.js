L.extend(L.Control.MiniMap.prototype,{
	hideText: 'Miniaturkarte ausblenden',
	showText: 'Miniaturkarte einblenden'
});
