<!DOCTYPE html>
<html>
<head>
	<title>Sumber Daya</title>
</head>
<body>

	<h2>Sumber Daya</h2>
	
	<table border="1">
		<tr>
			<th>NO</th>
			<th>ID Sumber Daya</th>
			<th>Nama Sumber Daya</th>
			<th>Ket</th>
		</tr>

		<?php 
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($db,"select * from sumber_daya");
		while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $d['id_sumber_daya']; ?></td>
				<td><?php echo $d['nama_sumber_daya']; ?></td>
				<td>
					<a href="lokasi_sumberdaya.php">MAP</a>
					<a href="detail-sumberdaya.php?id_sumber_daya=<?php echo $d['id_sumber_daya']; ?>">DETAIL</a>
				</td>
			</tr>
			<?php 
		}
		?>
	</table>
</body>
</html>