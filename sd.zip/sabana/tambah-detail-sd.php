<!DOCTYPE html>
<html>
<head>
	<title>CRUD Detail Sumberdaya</title>
</head>
<body>

	<h2>CRUD DETAIL SUMBER DAYA</h2>
	<br/>
	<a href="index-detail-sd.php">KEMBALI</a>
	<br/>
	<br/>
	<h3>TAMBAH DATA DETAIL SUMBER DAYA</h3>
	<form method="post" action="tambah-aksi-detail-sd.php">
		<table>
			<tr>			
				<td>ID TIM SAR</td>
				<td><input type="text" name="id_tim_sar"></td>
			</tr>
			<tr>
				<td>ID SUMBER DAYA</td>
				<td><input type="text" name="id_sumber_daya"></td>
			</tr>
			<tr>
				<td>NIK KORBAN</td>
				<td><input type="text" name="nik_korban"></td>
			</tr>
			<tr>
				<td>JENIS BENCANA</td>
				<td><input type="text" name="jenis_bencana"></td>
			</tr>
			<tr>
				<td>TANGGAL BENCANA</td>
				<td><input type="date" name="tgl_bencana"></td>
			</tr>
			<tr>
				<td>NO URUT</td>
				<td><input type="text" name="no_urut"></td>
			</tr>
			<tr>
				<td>JUMLAH SUMBER DAYA</td>
				<td><input type="text" name="jumlah_sumber_daya"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
</body>
</html>