<!DOCTYPE html>
<html>
<head>
	<title>CRUD PHP dan MySQLi - WWW.MALASNGODING.COM</title>
</head>
<body>

	<h2>CRUD Detail Sumberdaya</h2>
	<br/>
	<a href="tambah-detail-sd.php">+ TAMBAH DETAIL SUMBER DAYA</a>
	<br/>
	<br/>
	<table border="1">
		<tr>
			<th>NO</th>
			<th>ID TIM SAR</th>
			<th>ID SUMBER DAYA</th>
			<th>NIK KORBAN</th>
			<th>JENIS BENCANA</th>
			<th>TANGGAL BENCANA</th>
			<th>NO URUT</th>
			<th>JUMLAH SUMBER DAYA</th>
			<th>OPSI</th>
		</tr>
		<?php 
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($db,"select * from detail_sumber_daya");
		while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $d['id_tim_sar']; ?></td>
				<td><?php echo $d['id_sumber_daya']; ?></td>
				<td><?php echo $d['nik_korban']; ?></td>
				<td><?php echo $d['jenis_bencana']; ?></td>
				<td><?php echo $d['tgl_bencana']; ?></td>
				<td><?php echo $d['no_urut']; ?></td>
				<td><?php echo $d['jumlah_sumber_daya']; ?></td>
				<td>
					<a href="edit-detail-sd.php?id_sumber_daya=<?php echo $d['id_sumber_daya']; ?>">EDIT</a>
					<a href="hapus-detail-sd.php?id_sumber_daya=<?php echo $d['id_sumber_daya']; ?>">HAPUS</a>
				</td>
			</tr>
			<?php 
		}
		?>
	</table>
</body>
</html>