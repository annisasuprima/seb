<?php 

    require '../model/fungsikorban.php';

?> 