<?php 

    require '../model/fungsi.php';

?> 