<!DOCTYPE html>
<html>
<head>
	<title>print</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<div>
<h4>Data Bantuan</h4>
<a class="tombol" href="http://localhost/sabana/Cetak/print_bantuan.php">SHOW</a>
<a  class="tombol" href="http://localhost/sabana/detail_korban/print.php">PRINT</a>
<a class="tombol" href="http://localhost/sabana/menu.html">BACK</a>
</div>
<div>
<h4>Data Korban</h4>
<a class="tombol" href="http://localhost/sabana/Cetak/print_korban.php">SHOW</a>
<a  class="tombol" href="http://localhost/sabana/detail_korban/print.php">PRINT</a>
<a class="tombol" href="http://localhost/sabana/menu.html">BACK</a>
</div>
<div>

</body>
</html>

